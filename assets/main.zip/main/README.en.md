## About Us
See [About Us](https://github.com/HKEMS-STMO/New-official-website/blob/main/README.md "About Us") for more information.

Fun fact: Feel free to use the source code of this site in any way you like.  
This README is also available in [Chinese](README.md).

## License
Copyright © 2025 HKEMS-STMO.  
This is free software: you are free to change and redistribute it under the terms of the [**WTFPL**](http://www.wtfpl.net/) license.

[![WTFPL License](https://img.shields.io/badge/License-WTFPL-brightgreen.svg)](http://www.wtfpl.net/)

**Summary**:
- 🚫 No restrictions.
- 📛 No requirements.
- ❌ No warranties.

In case of any discrepancies, the Chinese version shall prevail.  
See the full license in the [LICENSE](LICENSE) file.  
