## 关于我们  
详见 [关于我们](https://github.com/HKEMS-STMO/New-official-website/blob/main/README.md "查看详细介绍")  

冷知识：你可以随意使用本站的源代码。  
This README.md is available in [English](README.en.md)  

## 开源协议  
版权所有 © 2026 HKEMS-STMO  
本软件为免费软件：您可以根据 [WTFPL](http://www.wtfpl.net/) 条款自由修改和重新分发本软件。  

[![WTFPL](https://img.shields.io/badge/许可证-WTFPL-ff69b4.svg)](http://www.wtfpl.net/)
完整协议见：[LICENSE](LICENSE) 文件